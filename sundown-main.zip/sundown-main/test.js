var a = document.querySelector("img")

var b = a.getAttribute("data-company")
console.log(b)